# plant_disease_classification_model
Build a UI for farmers to upload images of crops. Develop a deep learning model to identify diseases in crops
